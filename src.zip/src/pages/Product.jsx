import { useParams, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { FiStar, FiHeart, FiShoppingBag, FiShare2 } from 'react-icons/fi';
import products from '../data/products';
import '../styles/Product.css';

function Product() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const [isLeaving, setIsLeaving] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [activeTab, setActiveTab] = useState('description');

  const product = products.find((p) => p.id === Number(id));

  const handleBack = () => {
    setIsLeaving(true);
    setTimeout(() => navigate(-1), 400);
  };

  const handleAddToCart = () => {
    addToCart(product);
    setShowMessage(true);
    setTimeout(() => setShowMessage(false), 2000);
  };

  if (!product) return <h2 className="not-found">Товар не найден</h2>;

  return (
    <div className={`product-page ${isLeaving ? 'leave-animation' : ''}`}>
      <div className="product-header glass">
        <button className="back-button" onClick={handleBack}>← Назад</button>
        <h1>{product.brand}</h1>
        <button className="share-button">
          <FiShare2 />
        </button>
      </div>

      <div className="product-content">
        <div className="product-main">
          <div className="product-gallery glass">
            <div className="product-image-wrapper">
              <img src={product.image} alt={product.name} className="product-image" />
              <button className="favorite-button glass">
                <FiHeart />
              </button>
            </div>
          </div>

          <div className="product-info glass">
            <div className="product-info-header">
              <h2 className="product-name">{product.name}</h2>
              <div className="product-meta">
                <span className="product-type">{product.type}</span>
                <span className="product-volume">{product.volume}</span>
              </div>
            </div>

            <div className="product-rating">
              <FiStar />
              <span className="rating-value">{product.rating}</span>
              <span className="rating-count">(12 отзывов)</span>
            </div>

            <div className="product-price-block">
              <div className="price-info">
                <span className="product-price">
                  {new Intl.NumberFormat('ru-RU').format(product.price)} ₽
                </span>
                <span className="price-note">Доставка по России бесплатно</span>
              </div>
              <button className="add-to-cart-btn" onClick={handleAddToCart}>
                <FiShoppingBag />
                <span>Добавить в корзину</span>
              </button>
            </div>

            <div className="product-tabs">
              <div className="tabs-header">
                <button 
                  className={`tab-btn ${activeTab === 'description' ? 'active' : ''}`}
                  onClick={() => setActiveTab('description')}
                >
                  Описание
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'pyramid' ? 'active' : ''}`}
                  onClick={() => setActiveTab('pyramid')}
                >
                  Пирамида аромата
                </button>
                <button 
                  className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`}
                  onClick={() => setActiveTab('details')}
                >
                  Характеристики
                </button>
              </div>

              <div className="tab-content">
                {activeTab === 'description' && (
                  <div className="description-tab">
                    <p>{product.description}</p>
                  </div>
                )}

                {activeTab === 'pyramid' && (
                  <div className="pyramid-tab">
                    <div className="notes-section">
                      <h3>Верхние ноты</h3>
                      <div className="notes-list">
                        {product.scentPyramid.top.map((note, index) => (
                          <span key={index} className="note">{note}</span>
                        ))}
                      </div>
                    </div>
                    <div className="notes-section">
                      <h3>Ноты сердца</h3>
                      <div className="notes-list">
                        {product.scentPyramid.middle.map((note, index) => (
                          <span key={index} className="note">{note}</span>
                        ))}
                      </div>
                    </div>
                    <div className="notes-section">
                      <h3>Базовые ноты</h3>
                      <div className="notes-list">
                        {product.scentPyramid.base.map((note, index) => (
                          <span key={index} className="note">{note}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'details' && (
                  <div className="details-tab">
                    <div className="detail-row">
                      <span className="detail-label">Бренд</span>
                      <span className="detail-value">{product.brand}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Год выпуска</span>
                      <span className="detail-value">{product.year}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Пол</span>
                      <span className="detail-value">
                        {product.gender === 'men' ? 'Мужской' :
                         product.gender === 'women' ? 'Женский' : 'Унисекс'}
                      </span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Объём</span>
                      <span className="detail-value">{product.volume}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">Тип аромата</span>
                      <span className="detail-value">{product.type}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {showMessage && (
        <div className="cart-toast glass">
          Товар добавлен в корзину
          <span className="checkmark">✓</span>
        </div>
      )}
    </div>
  );
}

export default Product;
